import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { motion } from 'framer-motion';
import { Bell, Calendar, AlertTriangle, CheckCircle, Info, MessageCircle, Send } from 'lucide-react';
import { apiFetch } from '@/lib/api';
import { toast } from 'sonner';

const typeIcons: Record<string, any> = {
  event: Calendar,
  warning: AlertTriangle,
  success: CheckCircle,
  info: Info,
};

const typeStyles: Record<string, string> = {
  event: 'bg-info/10 text-info',
  warning: 'bg-warning/10 text-warning',
  success: 'bg-success/10 text-success',
  info: 'bg-primary/10 text-primary',
};

export default function NotificationsPage() {
  const { notifications, markNotificationRead } = useAppStore();
  
  const [queryMsg, setQueryMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!queryMsg) return;
    setIsSubmitting(true);
    try {
      await apiFetch('/queries', {
        method: 'POST',
        body: JSON.stringify({ message: queryMsg })
      });
      toast.success('Query submitted to Administration!');
      setQueryMsg('');
    } catch(e) {
      toast.error('Failed to submit query');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-foreground flex items-center gap-2">
          <Bell size={24} /> Notifications & Inbox
        </h1>
        <span className="text-sm text-muted-foreground font-medium">
          {notifications.filter((n) => !n.read).length} unread
        </span>
      </div>

      {/* Ask a Query */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-r from-primary/10 via-background to-background p-6 rounded-2xl border border-primary/20 shadow-sm relative overflow-hidden">
         <div className="absolute -right-4 -top-4 w-24 h-24 bg-primary/10 rounded-full blur-2xl pointer-events-none" />
         <h2 className="text-lg font-semibold flex items-center gap-2 mb-2 text-foreground">
            <MessageCircle size={18} className="text-primary" />
            Have a question?
         </h2>
         <p className="text-sm text-muted-foreground mb-4">Send a direct query to the administration panel. You'll receive a reply right here in your inbox.</p>
         <form onSubmit={handleSubmitQuery} className="flex gap-3">
            <input 
              type="text"
              value={queryMsg}
              onChange={e => setQueryMsg(e.target.value)}
              placeholder="e.g. My attendance for Physics is marked incorrect."
              className="flex-1 px-4 py-2 border rounded-xl bg-background/50 backdrop-blur-sm focus:ring-2 focus:ring-primary/50"
              required
            />
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="px-5 py-2 bg-primary text-primary-foreground font-medium rounded-xl flex items-center gap-2 hover:opacity-90 disabled:opacity-50 transition-all shadow-glow"
            >
               <Send size={16} /> Send Query
            </button>
         </form>
      </motion.div>

      <h2 className="text-lg font-semibold pt-4">Your Recent Alerts</h2>
      
      <div className="space-y-3">
        {notifications.length === 0 ? <p className="text-sm text-muted-foreground">You have no notifications yet.</p> : null}
        
        {notifications.map((notif, i) => {
          const type = notif.type || 'info';
          const Icon = typeIcons[type] || Info;
          const style = typeStyles[type] || typeStyles.info;
          
          return (
            <motion.div
              key={notif.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => markNotificationRead(notif.id)}
              className={`p-4 rounded-xl border shadow-soft cursor-pointer transition-colors ${
                notif.read ? 'bg-card border-border' : 'bg-card border-primary/20 shadow-glow'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${style}`}>
                  <Icon size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold text-foreground">
                      {notif.title || (notif.message.includes('Re:') ? 'Query Reply' : 'System Alert')}
                    </h3>
                    {!notif.read && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5 font-medium">{notif.message}</p>
                  <p className="text-xs text-muted-foreground mt-2 opacity-80">{notif.date || notif.createdAt}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
