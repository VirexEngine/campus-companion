import sqlite3
from werkzeug.security import generate_password_hash

def init_db():
    conn = sqlite3.connect('database.db')
    with open('schema.sql') as f:
        conn.executescript(f.read())

    cur = conn.cursor()

    # Pre-populate admin
    cur.execute("INSERT INTO users (user_id, name, email, department, password, role) VALUES (?, ?, ?, ?, ?, ?)",
                ('ADM-0001', 'Pratyush', 'pratyush@qqq.qqq', 'Management', generate_password_hash('1234'), 'admin'))
    
    # Pre-populate student
    cur.execute("INSERT INTO users (user_id, name, email, department, password, role) VALUES (?, ?, ?, ?, ?, ?)",
                ('STU-1001', 'Arjun Sharma', 'student@college.edu', 'CSE', generate_password_hash('student123'), 'student'))

    # Pre-populate teacher
    cur.execute("INSERT INTO users (user_id, name, email, department, password, role) VALUES (?, ?, ?, ?, ?, ?)",
                ('TCH-2001', 'Dr. Priya Nair', 'teacher@college.edu', 'DS', generate_password_hash('teacher123'), 'teacher'))

    # Add subjects for STU-1001 and TCH-2001
    subjects = ['Maths', 'BEE', 'EVS', 'PPS', 'Physics']
    for subj in subjects:
        cur.execute("INSERT INTO user_subjects (user_id, subject) VALUES (?, ?)", ('STU-1001', subj))
        cur.execute("INSERT INTO user_subjects (user_id, subject) VALUES (?, ?)", ('TCH-2001', subj))

    # Dummy attendance data
    for idx, subj in enumerate(subjects):
        cur.execute("INSERT INTO attendance (user_id, subject, date, status) VALUES (?, ?, ?, ?)",
                    ('STU-1001', subj, '2026-03-20', 'present'))

    cur.execute("INSERT INTO timetable (user_id, subject, day, start_time, end_time, teacher, room) VALUES (?, ?, ?, ?, ?, ?, ?)",
                ('STU-1001', 'Physics', 'Monday', '09:00', '10:00', 'Dr. Priya Nair', 'CS-101'))

    cur.execute("INSERT INTO notifications (user_id, message, type, date, is_read) VALUES (?, ?, ?, ?, ?)",
                ('STU-1001', 'Low Attendance Warning for Physics.', 'warning', '2026-03-19', False))

    cur.execute("INSERT INTO tasks (user_id, title, description, due_date, completed, priority) VALUES (?, ?, ?, ?, ?, ?)",
                ('STU-1001', 'Maths Assignment 3', 'Complete Calculus integration problems', '2026-03-22', False, 'high'))

    conn.commit()
    conn.close()
    print("Database seeded successfully.")

if __name__ == '__main__':
    init_db()
