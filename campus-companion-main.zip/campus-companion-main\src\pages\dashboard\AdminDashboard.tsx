import StatCard from '@/components/shared/StatCard';
import { Users, GraduationCap, CalendarCheck, MessageCircle, TrendingUp, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-foreground">Admin Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Complete overview of your institution</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard title="Total Students" value={1247} icon={GraduationCap} variant="primary" trend={{ value: 5.2, positive: true }} />
        <StatCard title="Total Teachers" value={86} icon={Users} variant="accent" />
        <StatCard title="Avg Attendance" value="82%" icon={CalendarCheck} variant="success" trend={{ value: 2.1, positive: true }} />
        <StatCard title="Pending Queries" value={14} icon={MessageCircle} variant="warning" />
        <StatCard title="Active Users" value={342} subtitle="Today" icon={TrendingUp} variant="primary" />
        <StatCard title="Low Attendance Alerts" value={23} icon={AlertTriangle} variant="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-xl border border-border shadow-soft p-5">
          <h2 className="font-display font-semibold text-foreground mb-4">Department Overview</h2>
          <div className="space-y-3">
            {[
              { dept: 'Computer Science', students: 320, attendance: 85 },
              { dept: 'Electronics', students: 280, attendance: 79 },
              { dept: 'Mechanical', students: 250, attendance: 82 },
              { dept: 'Civil', students: 210, attendance: 88 },
              { dept: 'Electrical', students: 187, attendance: 76 },
            ].map((d) => (
              <div key={d.dept} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div>
                  <p className="text-sm font-medium text-foreground">{d.dept}</p>
                  <p className="text-xs text-muted-foreground">{d.students} students</p>
                </div>
                <span className={`text-sm font-semibold ${d.attendance < 80 ? 'text-destructive' : 'text-success'}`}>
                  {d.attendance}%
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card rounded-xl border border-border shadow-soft p-5">
          <h2 className="font-display font-semibold text-foreground mb-4">Recent Queries</h2>
          <div className="space-y-3">
            {[
              { query: 'When are the mid-sem exams?', from: 'Student', status: 'pending' },
              { query: 'Hostel fee payment deadline?', from: 'Parent', status: 'answered' },
              { query: 'Library card renewal process?', from: 'Student', status: 'pending' },
              { query: 'Course change request', from: 'Student', status: 'pending' },
            ].map((q, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-foreground truncate">{q.query}</p>
                  <p className="text-xs text-muted-foreground">{q.from}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ml-2 ${
                  q.status === 'pending' ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'
                }`}>
                  {q.status}
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
