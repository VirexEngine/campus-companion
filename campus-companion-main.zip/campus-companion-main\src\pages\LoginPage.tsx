import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore, UserRole } from '@/store/authStore';
import { motion, AnimatePresence } from 'framer-motion';
import { GraduationCap, Eye, EyeOff, ArrowRight, UserPlus, LogIn } from 'lucide-react';
import { toast } from 'sonner';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('student');
  const [department, setDepartment] = useState('');

  const [loading, setLoading] = useState(false);
  const { login, signup } = useAuthStore();
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (isLogin) {
      const success = await login(userId, password);
      setLoading(false);
      if (success) {
        toast.success('Welcome back!');
        navigate('/dashboard');
      } else {
        toast.error('Invalid ID or password.');
      }
    } else {
      const generatedId = await signup({ name, email, password, role, department });
      setLoading(false);
      if (generatedId) {
        toast.success(`Signup successful! Your ID is: ${generatedId}`);
        toast.info('Please use your new ID to log in.');
        setUserId(generatedId);
        setIsLogin(true);
      } else {
        toast.error('Signup failed. Email may already be in use.');
      }
    }
  };

  const quickLogin = async (uid: string, pass: string) => {
    setUserId(uid);
    setPassword(pass);
    setLoading(true);
    const success = await login(uid, pass);
    setLoading(false);
    if (success) {
      toast.success('Welcome back!');
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <motion.div initial={{ y: -20 }} animate={{ y: 0 }} className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center shadow-glow">
              <GraduationCap size={28} className="text-primary-foreground" />
            </div>
            <h1 className="font-display text-3xl font-bold text-primary-foreground">CampusHub</h1>
          </motion.div>
          <p className="text-primary-foreground/60 text-sm">Your AI-Powered College Companion</p>
        </div>

        <div className="bg-card rounded-2xl shadow-medium p-8 border border-border overflow-hidden relative">
          
          <div className="flex gap-4 mb-6 border-b border-border pb-4">
            <button 
              type="button"
              onClick={() => setIsLogin(true)} 
              className={`flex-1 font-semibold flex items-center justify-center gap-2 pb-2 border-b-2 transition-all ${isLogin ? 'border-primary text-primary' : 'border-transparent text-muted-foreground'}`}>
              <LogIn size={18} /> Sign In
            </button>
            <button 
              type="button"
              onClick={() => setIsLogin(false)} 
              className={`flex-1 font-semibold flex items-center justify-center gap-2 pb-2 border-b-2 transition-all ${!isLogin ? 'border-primary text-primary' : 'border-transparent text-muted-foreground'}`}>
              <UserPlus size={18} /> Sign Up
            </button>
          </div>

          <form onSubmit={handleAuth} className="space-y-4">
            <AnimatePresence mode="wait">
              {!isLogin && (
                <motion.div
                  key="signup-fields"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 overflow-hidden"
                >
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">Full Name</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="John Doe"
                      className="w-full px-4 py-2.5 rounded-lg border border-input bg-background"
                      required={!isLogin}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="john@college.edu"
                      className="w-full px-4 py-2.5 rounded-lg border border-input bg-background"
                      required={!isLogin}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Role</label>
                      <select 
                        value={role} 
                        onChange={(e) => setRole(e.target.value as UserRole)}
                        className="w-full px-4 py-2.5 rounded-lg border border-input bg-background"
                      >
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Department</label>
                      <select
                        value={department}
                        onChange={(e) => setDepartment(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-lg border border-input bg-background"
                      >
                        <option value="CSE">CSE</option>
                        <option value="DS">DS</option>
                        <option value="CSE AI-ML">CSE AI-ML</option>
                      </select>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {isLogin && (
              <motion.div key="login-field" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Student/Teacher ID</label>
                <input
                  type="text"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="STU-1001"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-background focus:ring-2 focus:ring-ring transition-shadow"
                  required={isLogin}
                />
              </motion.div>
            )}

            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-lg border border-input bg-background pr-10 focus:ring-2 focus:ring-ring transition-shadow"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 mt-2 rounded-lg gradient-primary text-primary-foreground font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50 shadow-glow"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>{isLogin ? 'Sign In' : 'Create Account'} <ArrowRight size={18} /></>
              )}
            </button>
          </form>

          {isLogin && (
            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3 text-center">Quick demo login</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Student', uid: 'STU-1001', pass: 'student123' },
                  { label: 'Teacher', uid: 'TCH-2001', pass: 'teacher123' },
                ].map((demo) => (
                  <button
                    key={demo.label}
                    onClick={() => quickLogin(demo.uid, demo.pass)}
                    className="py-2 px-3 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                  >
                    {demo.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
