import { motion } from 'framer-motion';
import { Search, MoreVertical } from 'lucide-react';
import { useState } from 'react';

const STUDENTS = [
  { id: '1', name: 'Arjun Sharma', rollNo: 'CS001', department: 'Computer Science', attendance: 85, status: 'active' },
  { id: '2', name: 'Sneha Patel', rollNo: 'CS002', department: 'Computer Science', attendance: 92, status: 'active' },
  { id: '3', name: 'Vikram Singh', rollNo: 'EC001', department: 'Electronics', attendance: 68, status: 'warning' },
  { id: '4', name: 'Ananya Gupta', rollNo: 'ME001', department: 'Mechanical', attendance: 78, status: 'active' },
  { id: '5', name: 'Rahul Joshi', rollNo: 'CS003', department: 'Computer Science', attendance: 55, status: 'critical' },
  { id: '6', name: 'Priya Menon', rollNo: 'EC002', department: 'Electronics', attendance: 90, status: 'active' },
];

export default function AdminStudentsPage() {
  const [search, setSearch] = useState('');
  const filtered = STUDENTS.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) || s.rollNo.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-bold text-foreground">Manage Students</h1>

      <div className="relative max-w-sm">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search students..."
          className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring text-sm"
        />
      </div>

      <div className="bg-card rounded-xl border border-border shadow-soft overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Student</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Roll No</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Department</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Attendance</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((student, i) => (
                <motion.tr
                  key={student.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.03 }}
                  className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-xs font-bold">
                        {student.name.charAt(0)}
                      </div>
                      <span className="text-sm font-medium text-foreground">{student.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{student.rollNo}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{student.department}</td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-semibold ${student.attendance < 75 ? 'text-destructive' : 'text-success'}`}>
                      {student.attendance}%
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      student.status === 'active' ? 'bg-success/10 text-success' :
                      student.status === 'warning' ? 'bg-warning/10 text-warning' : 'bg-destructive/10 text-destructive'
                    }`}>
                      {student.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button className="p-1 rounded hover:bg-muted text-muted-foreground">
                      <MoreVertical size={16} />
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
