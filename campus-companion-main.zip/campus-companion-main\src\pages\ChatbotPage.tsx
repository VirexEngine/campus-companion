import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { apiFetch } from '@/lib/api';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const QUICK_QUESTIONS = [
  'What courses does the CS department offer?',
  'How to apply for admission?',
  'What are the hostel fees?',
  'When is the next exam?',
];

export default function ChatbotPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      role: 'assistant',
      content: "Hi! I'm CampusBot 🎓 — your elite AI college assistant. I am loading your structured knowledge base...",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [knowledgeContext, setKnowledgeContext] = useState('');
  
  // Cache Buster for Browser
  console.log("Vite HMR Trigger: Elite Model Activated");
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    const loadKnowledge = async () => {
      try {
        const response = await fetch('/cleaned_knowledge.txt');
        const text = await response.text();
        setKnowledgeContext(text);
        setIsReady(true);
        setMessages(prev => [
          ...prev.filter(m => m.id !== '0'), 
          {
            id: '1',
            role: 'assistant',
            content: "Ready! I am now powered by an elite intellectual LLM. I've read your entire 200-line structured college dataset and I'm ready to answer any question beautifully and instantly! ✨",
            timestamp: new Date()
          }
        ]);
      } catch (e) {
        console.error("Failed to load knowledge text:", e);
        setMessages(prev => [
          ...prev, 
          { id: 'err', role: 'assistant', content: "Failed to load the knowledge base file.", timestamp: new Date() }
        ]);
      }
    };

    loadKnowledge();
  }, []);

  const sendMessage = async (text: string) => {
    if (!text.trim() || !isReady) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: text, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      // Build conversation history for the AI
      const apiMessages = [
        { 
          role: 'system', 
          content: `You are CampusBot, an elite, highly intellectual AI college assistant (similar to Gemini). You answer questions brilliantly, clearly, and with perfect markdown formatting. 
                    You are incredibly smart and conversational. 
                    Here is the complete college knowledge base provided by the admin. ALWAYS use this context to answer college-specific questions accurately:\n\n${knowledgeContext}\n\nDo not invent false rules. If a user asks a general intellectual question, answer it brilliantly.`
        },
        // Only sending the last 5 messages to avoid token bloat
        ...messages.slice(-5).map(m => ({ role: m.role, content: m.content })),
        { role: 'user', content: text }
      ];

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          model: 'openai'
        })
      });

      if (!res.ok) throw new Error(`API Error: ${res.statusText}`);
      const data = await res.json();
      const finalAnswer = data.choices[0].message.content;

      setMessages(prev => [
        ...prev,
        { id: Date.now().toString(), role: 'assistant', content: finalAnswer, timestamp: new Date() }
      ]);
    } catch (err: any) {
      console.error("Pollinations error", err);
      setMessages(prev => [
        ...prev,
        { id: Date.now().toString(), role: 'assistant', content: `*(Generation Error: ${err.message})*`, timestamp: new Date() }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-6rem)] lg:h-[calc(100vh-4rem)]">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
          <Bot size={22} className="text-primary-foreground" />
        </div>
        <div>
          <h1 className="font-display text-xl font-bold text-foreground">Elite AI College Assistant</h1>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <span className={`w-2 h-2 rounded-full ${isReady ? 'bg-success' : 'bg-warning animate-pulse'}`} /> 
            {isReady ? 'Online & Ready (Elite Mode)' : 'Loading context...'}
          </p>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pr-2">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}
            >
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
                  <Bot size={16} className="text-primary-foreground" />
                </div>
              )}
              <div className={`max-w-[75%] p-3 rounded-xl text-sm leading-relaxed whitespace-pre-line ${
                msg.role === 'user'
                  ? 'gradient-primary text-primary-foreground rounded-br-sm'
                  : 'bg-card border border-border text-foreground rounded-bl-sm'
              }`}>
                {msg.content}
              </div>
              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-lg gradient-accent flex items-center justify-center flex-shrink-0">
                  <User size={16} className="text-accent-foreground" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {isTyping && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
              <Bot size={16} className="text-primary-foreground" />
            </div>
            <div className="bg-card border border-border rounded-xl rounded-bl-sm p-3 flex gap-1">
              <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:0.15s]" />
              <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:0.3s]" />
            </div>
          </motion.div>
        )}
      </div>

      {/* Quick questions */}
      {messages.length <= 2 && (
        <div className="flex gap-2 flex-wrap py-3">
          {QUICK_QUESTIONS.map((q) => (
            <button
              key={q}
              onClick={() => sendMessage(q)}
              className="px-3 py-1.5 rounded-full border border-border text-xs font-medium text-muted-foreground hover:bg-primary/5 hover:text-primary hover:border-primary/30 transition-colors flex items-center gap-1"
            >
              <Sparkles size={12} /> {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <form
        onSubmit={(e) => { e.preventDefault(); sendMessage(input); }}
        className="flex gap-2 pt-3 border-t border-border"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={isReady ? "Ask me anything about the college..." : "Loading AI model..."}
          disabled={!isReady || isTyping}
          className="flex-1 px-4 py-2.5 rounded-xl border border-input bg-background/50 focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={!input.trim() || isTyping || !isReady}
          className="p-2.5 rounded-xl gradient-primary text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50 shadow-glow"
        >
          <Send size={18} />
        </button>
      </form>
    </div>
  );
}
