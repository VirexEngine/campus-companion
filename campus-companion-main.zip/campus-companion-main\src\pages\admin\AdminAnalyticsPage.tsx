import StatCard from '@/components/shared/StatCard';
import { Users, GraduationCap, CalendarCheck, TrendingUp, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AdminAnalyticsPage() {
  const deptData = [
    { name: 'Computer Science', students: 320, avgAttendance: 85 },
    { name: 'Electronics', students: 280, avgAttendance: 79 },
    { name: 'Mechanical', students: 250, avgAttendance: 82 },
    { name: 'Civil', students: 210, avgAttendance: 88 },
    { name: 'Electrical', students: 187, avgAttendance: 76 },
  ];

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-bold text-foreground flex items-center gap-2">
        <BarChart3 size={24} /> Analytics
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Students" value={1247} icon={GraduationCap} variant="primary" trend={{ value: 5.2, positive: true }} />
        <StatCard title="Total Teachers" value={86} icon={Users} variant="accent" />
        <StatCard title="Avg Attendance" value="82%" icon={CalendarCheck} variant="success" />
        <StatCard title="Active Today" value={342} icon={TrendingUp} variant="primary" />
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-xl border border-border shadow-soft p-5">
        <h2 className="font-display font-semibold text-foreground mb-4">Department-wise Attendance</h2>
        <div className="space-y-4">
          {deptData.map((dept) => (
            <div key={dept.name} className="space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="font-medium text-foreground">{dept.name}</span>
                <span className="text-muted-foreground">{dept.students} students • <span className={dept.avgAttendance < 80 ? 'text-destructive font-semibold' : 'text-success font-semibold'}>{dept.avgAttendance}%</span></span>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${dept.avgAttendance}%` }}
                  transition={{ duration: 1 }}
                  className={`h-full rounded-full ${dept.avgAttendance < 80 ? 'bg-destructive' : 'bg-success'}`}
                />
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
