import { useState, useEffect } from 'react';
import { Shield, Key, Save, Edit, Trash2, UserPlus, X, BookOpen, Plus, Activity, MessageSquare, Send, Megaphone } from 'lucide-react';
import { useSettingsStore } from '../store/settingsStore';
import { apiFetch } from '@/lib/api';
import { User, UserRole } from '@/store/authStore';
import { TimetableEntry } from '@/store/appStore';
import { toast } from 'sonner';

export default function AdminPage() {
  const { geminiApiKey, setGeminiApiKey } = useSettingsStore();
  const [apiKeyInput, setApiKeyInput] = useState(geminiApiKey);

  const [users, setUsers] = useState<User[]>([]);
  const [timetable, setTimetable] = useState<TimetableEntry[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [queries, setQueries] = useState<any[]>([]);
  
  const [loading, setLoading] = useState(true);
  
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'student' as UserRole, department: 'CSE' });

  const [isAddingClass, setIsAddingClass] = useState(false);
  const [newClass, setNewClass] = useState({ user_id: '', subject: '', day: 'Monday', start_time: '', end_time: '', teacher: '', room: '' });

  const [replyText, setReplyText] = useState<{ [key: number]: string }>({});
  const [broadcastMsg, setBroadcastMsg] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [uData, tData, aData, qData] = await Promise.all([
        apiFetch('/admin/users'),
        apiFetch('/admin/timetable'),
        apiFetch('/admin/analytics'),
        apiFetch('/admin/queries')
      ]);
      setUsers(uData);
      setTimetable(tData);
      setAnalytics(aData);
      setQueries(qData);
    } catch (error) {
      toast.error('Failed to load admin data');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = () => {
    setGeminiApiKey(apiKeyInput);
    toast.success('System settings saved successfully!');
  };

  const handleDeleteUser = async (id: number) => {
    if (!confirm('Are you sure you want to delete this user?')) return;
    try {
      await apiFetch(`/admin/users/${id}`, { method: 'DELETE' });
      toast.success('User deleted');
      fetchData();
    } catch (e) {
      toast.error('Failed to delete user');
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    try {
      await apiFetch(`/admin/users/${editingUser.id}`, {
        method: 'PUT',
        body: JSON.stringify(editingUser)
      });
      toast.success('User updated');
      setEditingUser(null);
      fetchData();
    } catch (e) {
      toast.error('Failed to update user');
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiFetch('/admin/users', {
        method: 'POST',
        body: JSON.stringify(newUser)
      });
      toast.success(`User created! ID: ${res.user_id}`);
      setIsCreatingUser(false);
      setNewUser({ name: '', email: '', password: '', role: 'student', department: 'CSE' });
      fetchData();
    } catch (e) {
      toast.error('Failed to create user. Email may be duplicate.');
    }
  };

  const handleAddClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/admin/timetable', {
        method: 'POST',
        body: JSON.stringify(newClass)
      });
      toast.success('Timetable entry added');
      setIsAddingClass(false);
      setNewClass({ user_id: '', subject: '', day: 'Monday', start_time: '', end_time: '', teacher: '', room: '' });
      fetchData();
    } catch (e) {
      toast.error('Failed to add class');
    }
  };

  const handleDeleteClass = async (id: string) => {
     if (!confirm('Delete this timetable entry?')) return;
     try {
       await apiFetch(`/admin/timetable/${id}`, { method: 'DELETE' });
       toast.success('Class deleted');
       fetchData();
     } catch(e) {
       toast.error('Failed to delete class');
     }
  };

  const handleReplyQuery = async (queryId: number) => {
    const text = replyText[queryId];
    if (!text) return;
    try {
      await apiFetch(`/admin/queries/${queryId}/reply`, {
        method: 'POST',
        body: JSON.stringify({ reply: text })
      });
      toast.success('Reply sent successfully');
      setReplyText({ ...replyText, [queryId]: '' });
      fetchData();
    } catch(e) {
      toast.error('Failed to send reply');
    }
  };

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMsg) return;
    try {
      await apiFetch('/notifications/broadcast', {
        method: 'POST',
        body: JSON.stringify({ message: broadcastMsg, type: 'info' })
      });
      toast.success('Broadcast sent to all users');
      setBroadcastMsg('');
    } catch (err) {
      toast.error('Broadcast failed');
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <Shield className="text-primary" size={32} />
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">Manage settings, analytics, users, and queries.</p>
        </div>
      </div>

      <div className="grid gap-6">
        
        {/* Real Analytics */}
        {analytics && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-card border border-border rounded-xl p-5 shadow-sm text-center">
              <Activity size={24} className="text-primary mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Students</p>
              <p className="text-2xl font-bold mt-1">{analytics.total_students}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-5 shadow-sm text-center">
              <BookOpen size={24} className="text-indigo-500 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Teachers</p>
              <p className="text-2xl font-bold mt-1">{analytics.total_teachers}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-5 shadow-sm text-center">
              <MessageSquare size={24} className="text-orange-500 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Open Queries</p>
              <p className="text-2xl font-bold mt-1">{analytics.open_queries}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-5 shadow-sm text-center">
              <Shield size={24} className="text-green-500 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Attendance Logs</p>
              <p className="text-2xl font-bold mt-1">{analytics.total_attendance_records}</p>
            </div>
          </div>
        )}

        {/* Global Broadcast */}
        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm flex flex-col md:flex-row gap-6 items-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
            <Megaphone size={28} />
          </div>
          <div className="flex-1 w-full">
            <h2 className="text-lg font-semibold mb-2">Global Broadcast Annoucement</h2>
            <form onSubmit={handleBroadcast} className="flex gap-3">
              <input 
                type="text" 
                value={broadcastMsg}
                onChange={e => setBroadcastMsg(e.target.value)}
                placeholder="Type a message to instantly notify all students and teachers..."
                className="flex-1 px-4 py-2 border rounded-lg bg-background"
                required
              />
              <button type="submit" className="px-5 py-2 bg-primary text-primary-foreground font-medium rounded-lg flex items-center gap-2">
                <Send size={16} /> Broadcast
              </button>
            </form>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
           {/* Queries Responder */}
           <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
             <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
               <MessageSquare size={20} className="text-primary"/>
               Student & Teacher Queries
             </h2>
             {loading ? <p>Loading...</p> : (
               <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                 {queries.length === 0 ? <p className="text-sm text-muted-foreground">No queries available.</p> : queries.map(q => (
                   <div key={q.id} className="p-4 rounded-xl border border-border bg-muted/20">
                     <div className="flex justify-between items-start mb-2">
                       <div>
                         <p className="font-semibold text-sm">{q.name} <span className="text-xs font-normal text-muted-foreground bg-muted px-2 py-0.5 rounded-full ml-1">{q.role}</span></p>
                         <p className="text-xs text-muted-foreground">{new Date(q.created_at).toLocaleString()}</p>
                       </div>
                       <span className={`text-xs font-bold px-2 py-1 rounded-full ${q.status === 'resolved' ? 'bg-success/20 text-success' : 'bg-orange-500/20 text-orange-600'}`}>
                         {q.status.toUpperCase()}
                       </span>
                     </div>
                     <p className="text-sm mb-3 font-medium">{q.message}</p>
                     
                     {q.status === 'open' ? (
                       <div className="flex gap-2">
                         <input 
                           type="text" 
                           placeholder="Type a reply..."
                           className="flex-1 text-sm px-3 py-1.5 border rounded-md"
                           value={replyText[q.id] || ''}
                           onChange={e => setReplyText({...replyText, [q.id]: e.target.value})}
                         />
                         <button onClick={() => handleReplyQuery(q.id)} className="px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium">Send</button>
                       </div>
                     ) : (
                       <div className="bg-background p-3 rounded-lg border border-border text-sm">
                         <span className="font-bold text-primary text-xs block mb-1">Your Reply:</span>
                         {q.reply}
                       </div>
                     )}
                   </div>
                 ))}
               </div>
             )}
           </div>

           {/* API Settings */}
           <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Key size={20} className="text-primary"/>
                API Integrations
              </h2>
              <div className="space-y-4">
                 <label className="block text-sm font-medium mb-1">Google Gemini API Key</label>
                 <input
                    type="password"
                    value={apiKeyInput}
                    onChange={(e) => setApiKeyInput(e.target.value)}
                    placeholder="Paste your AI_API_KEY here..."
                    className="w-full px-4 py-2.5 rounded-xl border border-input bg-background/50"
                 />
                 <button onClick={handleSaveSettings} className="flex items-center gap-2 px-6 py-2 bg-primary text-primary-foreground rounded-xl w-full justify-center font-medium">
                    <Save size={18} /> Save Key
                 </button>
              </div>
           </div>
        </div>
        
        {/* User Management */}
        <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <UserPlus size={20} className="text-primary"/>
              User Accounts
            </h2>
            <button 
              onClick={() => setIsCreatingUser(true)}
              className="text-sm flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg"
            >
              <Plus size={16} /> Create User
            </button>
          </div>
          
          {loading ? (
             <div className="text-center p-4">Loading data...</div>
          ) : (
             <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                   <thead>
                      <tr className="border-b border-border">
                         <th className="p-3 font-medium text-muted-foreground text-sm">ID</th>
                         <th className="p-3 font-medium text-muted-foreground text-sm">Name</th>
                         <th className="p-3 font-medium text-muted-foreground text-sm">Email</th>
                         <th className="p-3 font-medium text-muted-foreground text-sm">Role</th>
                         <th className="p-3 font-medium text-muted-foreground text-sm">Dept</th>
                         <th className="p-3 font-medium text-muted-foreground text-sm">Actions</th>
                      </tr>
                   </thead>
                   <tbody>
                      {users.map((u) => (
                         <tr key={u.id} className="border-b border-border/50 hover:bg-muted/30">
                            <td className="p-3 text-sm font-mono text-primary">{u.user_id}</td>
                            <td className="p-3 text-sm font-medium">{u.name}</td>
                            <td className="p-3 text-sm">{u.email}</td>
                            <td className="p-3 text-sm capitalize">
                               <span className={`px-2 py-1 rounded-full text-xs font-semibold ${u.role === 'admin' ? 'bg-primary/20 text-primary' : 'bg-secondary text-secondary-foreground'}`}>
                                  {u.role}
                               </span>
                            </td>
                            <td className="p-3 text-sm text-muted-foreground">{u.department || 'N/A'}</td>
                            <td className="p-3">
                               <div className="flex items-center gap-2">
                                  <button onClick={() => setEditingUser(u)} className="p-1.5 text-blue-500 hover:bg-blue-500/10 rounded-md transition-colors"><Edit size={16} /></button>
                                  <button onClick={() => handleDeleteUser(u.id)} className="p-1.5 text-destructive hover:bg-destructive/10 rounded-md transition-colors"><Trash2 size={16} /></button>
                               </div>
                            </td>
                         </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          )}
        </div>

        {/* Timetable Management */}
        <div className="bg-card rounded-2xl p-6 border border-border shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <BookOpen size={20} className="text-primary"/>
              Master Timetable Classes
            </h2>
            <button 
              onClick={() => setIsAddingClass(true)}
              className="text-sm flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg"
            >
              <Plus size={16} /> Add Class
            </button>
          </div>
          
          <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-border">
                        <th className="p-3 font-medium text-muted-foreground text-sm">Assigned To (ID)</th>
                        <th className="p-3 font-medium text-muted-foreground text-sm">Subject</th>
                        <th className="p-3 font-medium text-muted-foreground text-sm">Day</th>
                        <th className="p-3 font-medium text-muted-foreground text-sm">Time</th>
                        <th className="p-3 font-medium text-muted-foreground text-sm">Room</th>
                        <th className="p-3 font-medium text-muted-foreground text-sm">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {timetable.map((t) => (
                        <tr key={t.id} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="p-3 text-sm font-mono text-primary">{t.user_id}</td>
                          <td className="p-3 text-sm">{t.subject}</td>
                          <td className="p-3 text-sm">{t.day}</td>
                          <td className="p-3 text-sm">{t.startTime || t.start_time} - {t.endTime || t.end_time}</td>
                          <td className="p-3 text-sm">{t.room}</td>
                          <td className="p-3">
                              <button onClick={() => handleDeleteClass(t.id)} className="p-1.5 text-destructive hover:bg-destructive/10 rounded-md transition-colors"><Trash2 size={16} /></button>
                          </td>
                        </tr>
                    ))}
                  </tbody>
              </table>
          </div>
        </div>

      </div>

      {/* Modals */}
      {isCreatingUser && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-card w-full max-w-md rounded-2xl shadow-xl border border-border p-6 relative">
              <button onClick={() => setIsCreatingUser(false)} className="absolute top-4 right-4 p-2">
                 <X size={20} />
              </button>
              <h2 className="text-xl font-semibold mb-6">Create New User</h2>
              <form onSubmit={handleCreateUser} className="space-y-4">
                 <div>
                    <label className="text-sm mb-1 block">Full Name</label>
                    <input type="text" value={newUser.name} onChange={(e) => setNewUser({...newUser, name: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                 </div>
                 <div>
                    <label className="text-sm mb-1 block">Email</label>
                    <input type="email" value={newUser.email} onChange={(e) => setNewUser({...newUser, email: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                 </div>
                 <div>
                    <label className="text-sm mb-1 block">Initial Password</label>
                    <input type="text" value={newUser.password} onChange={(e) => setNewUser({...newUser, password: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="text-sm mb-1 block">Role</label>
                       <select value={newUser.role} onChange={(e) => setNewUser({...newUser, role: e.target.value as any})} className="w-full px-4 py-2 border rounded-lg bg-background">
                          <option value="student">Student</option>
                          <option value="teacher">Teacher</option>
                          <option value="admin">Admin</option>
                       </select>
                    </div>
                    <div>
                       <label className="text-sm mb-1 block">Department</label>
                       <select value={newUser.department} onChange={(e) => setNewUser({...newUser, department: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background">
                          <option value="CSE">CSE</option>
                          <option value="DS">DS</option>
                          <option value="CSE AI-ML">CSE AI-ML</option>
                       </select>
                    </div>
                 </div>
                 <button type="submit" className="w-full py-2 bg-primary text-primary-foreground rounded-lg mt-4 font-medium">Create Account</button>
              </form>
           </div>
        </div>
      )}

      {editingUser && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-card w-full max-w-md rounded-2xl shadow-xl border border-border p-6 relative">
              <button onClick={() => setEditingUser(null)} className="absolute top-4 right-4 p-2 text-muted-foreground hover:bg-muted rounded-full">
                 <X size={20} />
              </button>
              <h2 className="text-xl font-semibold mb-6">Edit User ({editingUser.user_id})</h2>
              <form onSubmit={handleUpdateUser} className="space-y-4">
                 <div>
                    <label className="text-sm font-medium mb-1 block">Name</label>
                    <input type="text" value={editingUser.name} onChange={(e) => setEditingUser({...editingUser, name: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                 </div>
                 <div>
                    <label className="text-sm font-medium mb-1 block">Email</label>
                    <input type="email" value={editingUser.email} onChange={(e) => setEditingUser({...editingUser, email: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="text-sm font-medium mb-1 block">Role</label>
                       <select value={editingUser.role} onChange={(e) => setEditingUser({...editingUser, role: e.target.value as any})} className="w-full px-4 py-2 border rounded-lg bg-background">
                          <option value="student">Student</option>
                          <option value="teacher">Teacher</option>
                          <option value="admin">Admin</option>
                       </select>
                    </div>
                    <div>
                       <label className="text-sm font-medium mb-1 block">Department</label>
                       <select value={editingUser.department} onChange={(e) => setEditingUser({...editingUser, department: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background">
                          <option value="CSE">CSE</option>
                          <option value="DS">DS</option>
                          <option value="CSE AI-ML">CSE AI-ML</option>
                       </select>
                    </div>
                 </div>
                 <div className="pt-4 flex justify-end gap-3">
                    <button type="button" onClick={() => setEditingUser(null)} className="px-4 py-2 rounded-lg font-medium hover:bg-muted">Cancel</button>
                    <button type="submit" className="px-5 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90">Save Changes</button>
                 </div>
              </form>
           </div>
        </div>
      )}

      {isAddingClass && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-card w-full max-w-md rounded-2xl shadow-xl border border-border p-6 relative">
              <button onClick={() => setIsAddingClass(false)} className="absolute top-4 right-4 p-2">
                 <X size={20} />
              </button>
              <h2 className="text-xl font-semibold mb-6">Add Class to Timetable</h2>
              <form onSubmit={handleAddClass} className="space-y-4">
                 <div>
                    <label className="text-sm mb-1 block">Assign To User ID (e.g. STU-1001)</label>
                    <input type="text" value={newClass.user_id} onChange={(e) => setNewClass({...newClass, user_id: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="text-sm mb-1 block">Subject</label>
                       <input type="text" value={newClass.subject} onChange={(e) => setNewClass({...newClass, subject: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                    </div>
                    <div>
                       <label className="text-sm mb-1 block">Day</label>
                       <select value={newClass.day} onChange={(e) => setNewClass({...newClass, day: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background">
                          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map(d => <option key={d}>{d}</option>)}
                       </select>
                    </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="text-sm mb-1 block">Start Time</label>
                       <input type="time" value={newClass.start_time} onChange={(e) => setNewClass({...newClass, start_time: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                    </div>
                    <div>
                       <label className="text-sm mb-1 block">End Time</label>
                       <input type="time" value={newClass.end_time} onChange={(e) => setNewClass({...newClass, end_time: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                    </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="text-sm mb-1 block">Teacher Name</label>
                       <input type="text" value={newClass.teacher} onChange={(e) => setNewClass({...newClass, teacher: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                    </div>
                    <div>
                       <label className="text-sm mb-1 block">Room</label>
                       <input type="text" value={newClass.room} onChange={(e) => setNewClass({...newClass, room: e.target.value})} className="w-full px-4 py-2 border rounded-lg bg-background" required />
                    </div>
                 </div>
                 <button type="submit" className="w-full py-2 bg-primary text-primary-foreground rounded-lg mt-4 font-medium">Add Class</button>
              </form>
           </div>
        </div>
      )}

    </div>
  );
}
