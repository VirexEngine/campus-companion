import { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Send } from 'lucide-react';

const QUERIES = [
  { id: '1', question: 'When are the mid-semester exams?', from: 'Arjun Sharma', date: '2026-03-20', status: 'pending' as const, reply: '' },
  { id: '2', question: 'Hostel fee payment deadline?', from: 'Sneha Patel', date: '2026-03-19', status: 'answered' as const, reply: 'The deadline is April 15, 2026.' },
  { id: '3', question: 'Library card renewal process?', from: 'Vikram Singh', date: '2026-03-18', status: 'pending' as const, reply: '' },
  { id: '4', question: 'Can I change my elective subject?', from: 'Ananya Gupta', date: '2026-03-17', status: 'pending' as const, reply: '' },
];

export default function AdminQueriesPage() {
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-bold text-foreground flex items-center gap-2">
        <MessageCircle size={24} /> Student Queries
      </h1>

      <div className="space-y-3">
        {QUERIES.map((query, i) => (
          <motion.div
            key={query.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="bg-card rounded-xl border border-border shadow-soft p-5"
          >
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="text-sm font-medium text-foreground">{query.question}</p>
                <p className="text-xs text-muted-foreground mt-1">From: {query.from} • {query.date}</p>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                query.status === 'pending' ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'
              }`}>
                {query.status}
              </span>
            </div>

            {query.reply && (
              <div className="mt-3 p-3 rounded-lg bg-success/5 border border-success/20">
                <p className="text-xs text-muted-foreground mb-1">Admin Reply:</p>
                <p className="text-sm text-foreground">{query.reply}</p>
              </div>
            )}

            {query.status === 'pending' && (
              <>
                {replyingTo === query.id ? (
                  <div className="mt-3 flex gap-2">
                    <input
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="Type your reply..."
                      className="flex-1 px-3 py-2 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                    <button className="p-2 rounded-lg gradient-primary text-primary-foreground shadow-glow">
                      <Send size={16} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setReplyingTo(query.id)}
                    className="mt-3 text-xs font-medium text-primary hover:underline"
                  >
                    Reply to this query
                  </button>
                )}
              </>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
}
